﻿using UnityEngine;

namespace TwoStickHybridExample
{

    public class Shot : MonoBehaviour
    {
        public float TimeToLive;
        public float Energy;
    }
}
