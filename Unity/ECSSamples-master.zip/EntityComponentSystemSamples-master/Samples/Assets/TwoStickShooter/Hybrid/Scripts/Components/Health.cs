﻿using UnityEngine;

namespace TwoStickHybridExample
{
    public class Health : MonoBehaviour
    {
        public float Value;
    }
}