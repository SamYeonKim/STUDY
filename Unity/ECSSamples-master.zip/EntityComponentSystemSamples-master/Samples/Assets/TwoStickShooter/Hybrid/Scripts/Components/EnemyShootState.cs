﻿using UnityEngine;

namespace TwoStickHybridExample
{
    public class EnemyShootState : MonoBehaviour
    {
        public float Cooldown;
    }
}