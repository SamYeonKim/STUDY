﻿using UnityEngine;

namespace TwoStickHybridExample
{
    public class Enemy : MonoBehaviour {} // Pure marker type
}
