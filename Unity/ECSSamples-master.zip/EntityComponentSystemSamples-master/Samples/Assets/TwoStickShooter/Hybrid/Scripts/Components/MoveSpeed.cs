﻿using UnityEngine;

namespace TwoStickHybridExample
{
    public class MoveSpeed : MonoBehaviour
    {
        public float Value;
    }
}