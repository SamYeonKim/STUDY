﻿using Unity.Mathematics;
using UnityEngine;

namespace TwoStickHybridExample
{
    public class Position2D : MonoBehaviour
    {
        public float2 Value;
    }
}