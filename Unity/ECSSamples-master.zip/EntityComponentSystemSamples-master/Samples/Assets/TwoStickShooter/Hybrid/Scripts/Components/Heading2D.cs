﻿using Unity.Mathematics;
using UnityEngine;

namespace TwoStickHybridExample
{
    public class Heading2D : MonoBehaviour
    {
        public float2 Value;
    }
}